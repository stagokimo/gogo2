import axios from'axios';
import {baseURL_dev} from '../config/basURL.ts'

const instance = axios.create({
    baseURL: baseURL_dev,
    timeout: 30000,
    headers: {'X-Custom-Header': 'foobar'}
  });

export const $get = async(url:string, params:object={})=>{
    let {data} = await instance.get(url,{params})
    return data
}

export const $post = async(url:string, params:object={})=>{
    let {data} = await instance.post(url,{params})
    return data
}