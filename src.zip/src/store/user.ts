import { defineStore } from 'pinia'

interface userInfo {
    id: number,
    loginId: string,
    loginPwd: string,
    name: string,
    phone: string,
    phote: string,
    role: {
        roleId: number,
        roleName: string
    }
}

export default defineStore('user', {
    state() {
        return {
            user: null as userInfo | null
        }
    },
    actions:{
        setUser(user: userInfo) {
            this.user = user
        },
        clearUser() {
            this.user = null
            sessionStorage.clear()
        }
    }
})