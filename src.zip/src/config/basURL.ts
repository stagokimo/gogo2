export const baseURL_dev:string='http://localhost:3000/'
export const baseURL_prod:string='http://localhost:3000/'
export const baseURL_test:string='http://localhost:3000/'