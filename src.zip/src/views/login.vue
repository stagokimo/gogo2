<template>
    <div class="login">
        <div class="box">
          <h2>管理系統</h2>
            <el-form
                size="small"
                ref="formRef"
                :model="formData"
                status-icon
                :rules="rules"
                label-width="40px">

                <el-form-item label="帳號" prop="loginId">
                    <el-input v-model="formData.loginId" />
                </el-form-item>
                <el-form-item label="密碼" prop="loginPwd">
                    <el-input v-model="formData.loginPwd" type="password" />
                </el-form-item>
               
                <el-form-item>
                    <el-button type="primary" @click="submitForm(formRef)">
                        登入
                    </el-button>
                    <el-button @click="resetForm(formRef)">取消</el-button>
                </el-form-item>
                
            </el-form>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { reactive, ref, onMounted } from 'vue'
//element-plus 
import type { FormInstance, FormRules } from 'element-plus'

//
import  {$login, $getOne} from '../api/admin.ts'

//
import {useRouter} from 'vue-router'
import useUser from '../store/user.ts'

//
const router = useRouter()
const userStore = useUser()

//綁定表單
const formRef = ref<FormInstance>()

//表單
const formData = reactive({
  loginId:'',
  loginPwd: ''
})


const validateLoginPwd = (rule: any, value: any, callback: any) => {
  if (value === '') {
    callback(new Error('Please input the password'))
  } else {
    callback()
  }
}

const validateLoginId = (rule: any, value: any, callback: any) => {
  if (value === '') {
    callback(new Error('Please input the account'))
  } else {
    callback()
  } 
}

const rules = reactive<FormRules<typeof formData>>({
  loginId: [{ validator: validateLoginId, trigger: 'blur' }],
  loginPwd: [{ validator: validateLoginPwd, trigger: 'blur' }],
})

const submitForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.validate(async (valid) => {
    if (valid) {

      //
      let ret = await $login(formData)
      if(ret){

        //getOne
        let user = await $getOne(ret)
        console.log('user' , user)
        sessionStorage.setItem('user', JSON.stringify(user))
        userStore.setUser(user)
        router.push('/index')
      }

      formEl.resetFields()

    } else {
      console.log('error submit!')
      formEl.resetFields()
    }
  })
}

const resetForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.resetFields()
}

onMounted(() => {
    if(userStore.user?.loginId) {
        router.push('/index')
    }
})
</script>

<style scoped lang="scss">
.login{
    width: 100vw;
    height: 100vh;
    background: linear-gradient(to bottom, #142334, #6894c7);
    display: flex;
    justify-content: center;
    align-items: center;
    .box{
        width: 400px;
        height: 200px;
        border: 1px solid #ffff;
        padding: 20px;
        h2{
          color: white;
          font-size: 20px;
          text-align: center;
          margin-bottom: 20px;
        }
        ::v-deep .el-form-item__label{
            color: #fff;
        }
    }
}
</style>