<template>
    <div id="sideBar">
        <sideBar />
    </div>
    <div id="mainContent">
        <router-view></router-view>
    </div>
</template>

<script setup lang="ts">
import sideBar from '@/components/sideBar.vue';


</script>

<style scoped>
#sideBar {
    width: 250px;
    height: 100%;
    display: block;
    position: fixed;
    background: transparent;
    color: darkslategray;
}

#mainContent {
    margin-left: 250px;
    position: relative;
    padding: 20px;
}
</style>