<template>
    <div class="search">
     <el-button type="primary" size="small" @click="editRef.drawer=true">add</el-button>   
    </div>
    

    <div class="role">
        <el-table size="small" :data="roles" style="width: 98%">
            <el-table-column prop="roleId" label="roleId" width="100" />
            <el-table-column prop="roleName" label="roleName" width="250" />
            <el-table-column label="Operations">
            <template #default="scope">
                <el-button size="small" @click="handleEdit(scope.row.roleId)">
                Edit
                </el-button>
                <el-button
                size="small"
                type="danger"
                @click="handleDelete(scope.row.roleId)">
                Delete
                </el-button>
            </template>
            </el-table-column>
        </el-table>

        
        <EditRole ref="editRef"></EditRole>
    </div>
</template>

<script setup lang="ts">

import {$list} from '../../api/role.ts'
import {onMounted, ref} from 'vue'
import EditRole from '../../components/user/EditRole.vue';

//角色列表
let roles = ref([])

const loadRoles = async ()=>{
    roles.value = await $list()
}



onMounted(() => {
    loadRoles()
})

const handleEdit = (roleId:number) =>{
    console.log(roleId)
}

const handleDelete = (roleId:number) =>{
    console.log(roleId)
}

//
let editRef = ref()

</script>

<style lang="scss" scoped>
.search{
    margin: 5px;
}
</style>