<template>
    <div class="user">
        user
    </div>
</template>

<script setup lang="ts">
import Vue from 'vue'

</script>

<style lang="scss" scoped>

</style>