<template>
    <div class="home">
        home
    </div>
</template>

<script setup lang="ts">
import Vue from 'vue'

</script>

<style lang="scss" scoped>

</style>