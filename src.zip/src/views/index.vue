<template>
    <div class="index">
        <div class="left">
            <h2>Bing 管理系統</h2>
            <el-menu
                active-text-color="#ffd04b"
                background-color="#142334"
                default-active="2"
                text-color="#fff"
                router>
                <el-sub-menu index="1">
                    <template #title>
                        <el-icon><List /></el-icon>
                        <span>帳戶管理</span>
                    </template>
                    <el-menu-item index="/role">角色管理</el-menu-item>
                    <el-menu-item index="/user">用戶管理</el-menu-item>
                </el-sub-menu>
   
                <el-sub-menu index="2">
                    <template #title>
                        <el-icon><location /></el-icon>
                        <span>客房管理</span>
                    </template>
                    <el-menu-item index="/roomtype">房型管理</el-menu-item>
                    <el-menu-item index="/room">房間管理</el-menu-item>
                </el-sub-menu>

                <el-sub-menu index="3">
                    <template #title>
                        <el-icon><User /></el-icon>
                        <span>客戶管理</span>
                    </template>
                    <el-menu-item index="/livein">入住用戶</el-menu-item>
                    <el-menu-item index="/order">客戶訂單</el-menu-item>
                </el-sub-menu>

                <el-sub-menu index="4">
                    <template #title>
                        <el-icon><Setting /></el-icon>
                        <span>系統管理</span>
                    </template>
                    <el-menu-item index="/menu">菜單管理</el-menu-item>
                    <el-menu-item index="/dictionary">字典管理</el-menu-item>
                </el-sub-menu>
            </el-menu>
        </div>

        <div class="right">
            <div class="top">
                <el-menu
                router
                :ellipsis="false"
                mode="horizontal"
                active-text-color="#ffd04b"
                background-color="142334"
                text-color="#fff">
                <el-menu-item index="/index">
                    <el-icon><HomeFilled /></el-icon>
                    home
                </el-menu-item>
                <el-menu-item index="/mail">
                    <el-icon><ChatDotSquare /></el-icon>
                    mail
                </el-menu-item>
                <el-menu-item index="message">
                    <el-icon><Message /></el-icon>
                    message
                </el-menu-item>
                <el-sub-menu index="">
                    
                    <template #title>
                        <el-icon><Avatar /></el-icon>manager
                    </template>
                    <el-menu-item style="background-color: #142334;" index="/mine">個人中心</el-menu-item>
                    <el-menu-item style="background-color: #142334;" index="/setpwd">修改密碼</el-menu-item>
                    <el-menu-item @click="logout" style="background-color: #142334;" index="">登出</el-menu-item>              
                </el-sub-menu>

            </el-menu>
            </div>
            <div class="content">
                <router-view></router-view>
            </div>
        </div>
    </div>
  
</template>

<script setup lang="ts">
import { ElMessage, ElMessageBox } from 'element-plus'
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import {
  List,
  User,
  Location,
  Setting,
  HomeFilled,
  Message,
  Avatar,
  ChatDotSquare
} from '@element-plus/icons-vue'

import useUser from '../store/user.ts'
const userStore = useUser()
const router = useRouter()
onMounted(() => {
    if(!userStore.user?.loginId) {
        router.push('/')
    }
})

const logout = (() => {
    ElMessageBox.confirm(
    '確定要登出?',
    'Warning',
    {
      confirmButtonText: '是',
      cancelButtonText: '否',
      type: 'warning',
    }
  )
    .then(() => {
      ElMessage({
        type: 'success',
        message: '登出成功',
      })
      userStore.clearUser()
      router.push('/')
    })
    .catch(() => {
      ElMessage({
        type: 'info',
        message: '登出失敗',
      })
    })
    
  
})

</script>

<style>
.index{
    width: 100vw;
    height: 100vh;
    display: flex;
    .left{
        width: 200px;
        background-color:  #142334;
        color: white;
        .el-menu{
            border-right: none;
        }
        h2{
            font-size: 18px;
            text-align: center;
            height: 60px;
            line-height: 60px;
        }
    }
    .right{
        flex: 1;
        display: flex;
        flex-direction: column;

        .top{
            height: 60px;
            background-color:  #142334;
            display: flex;
            justify-content: flex-end;
            .el-sub-menu .el-menu-item{
                background-color:  #142334 !important;
            }
        }

        .content{
            flex: 1;
        }
    }

}
</style>