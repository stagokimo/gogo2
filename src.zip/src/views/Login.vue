<template>
  <div>
    <form @submit.prevent="onLogin"> 
      <label for="user">user : </label>
      <input type="text" v-model="userName" />
      <br />
      <label for="passwrd">passwrd : </label>
      <input type="text" v-model="userPassword" />
      <br />
      <button class="btn btn-primary" >登入</button>
    </form>
    
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import router from '../router/router'

const userName = ref('')
const userPassword = ref('')

const onLogin = async () => {
  console.log("userName : ",userName.value)
  console.log("userPassword : ", userPassword.value)

  

  if(userName.value != '' && userPassword.value != '') {
    router.push({name: 'home'});
  }else{
    alert('帳號密碼不能為空')
  }

}
</script>
