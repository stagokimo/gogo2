<template>
    <div class="message">
        message
    </div>
</template>

<script setup lang="ts">
import Vue from 'vue'

</script>

<style lang="scss" scoped>

</style>