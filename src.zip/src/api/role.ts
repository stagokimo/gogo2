import { $get, $post } from '../utils/request.ts'

//回傳角色列表
export const $list = async () => {
    let ret = await $get('Role/List')
    return ret
}