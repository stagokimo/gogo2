import {$post} from '../utils/request.ts'
import { md5 } from 'md5js';
import Cookies from 'js-cookie'
import { ElNotification } from 'element-plus'
import { h } from 'vue'

export const $login = async (params: any)=>{
    

    params.loginPwd = md5(params.loginPwd, 32)
    console.log(params)
    let {message, success, token} = await $post('Admin/Login', params)
    if(success) {
        //login success
        Cookies.set('token', token)
        ElNotification({
            title: 'Title',
            message: h('i', { style: 'color: teal' }, 'login success'),
        })
        return true
    }else{
        ElNotification({
            title: 'Title',
            message: h('i', { style: 'color: teal' }, 'login fail'),
        })
        return false
    }
}

export const $getOne = async (params: any) => {
    
    let ret = await $post('Admin/GetOne', params)

    console.log(ret)
    return ret
}