import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginView from '../views/Login.vue'
import AuthLayout from '@/views/layout/AuthLayout.vue'
import MainLayout from '@/views/layout/MainLayout.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'main',
      component: MainLayout,
      meta: { requireAuth: true }, // 用來作為此頁是否需要權限驗證的設定
      children: [
        {
          path: '/home',
          name: 'home',
          component: HomeView
        },
      ]
    },
    {
      path: '/',
      redirect: 'login',
      name: 'LoginView',
      component: AuthLayout,
      children: [
        {
          path: 'login',
          name: 'login',
          component: LoginView
        },
    
      ]
    },
   
  ]
})


router.beforeEach(async(to, from) => {
  // 看看 to 和 from 兩個 arguments 會吐回什麼訊息
  console.log('to: ', to)
  console.log('from: ', from)
  // 目的路由在meta上是否有設置requireAuth: true
  if (to.meta.requireAuth) {
  }
})

export default router
