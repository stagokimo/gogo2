import { createRouter, createWebHashHistory } from "vue-router"


const router = createRouter({
    history: createWebHashHistory(),
    routes:[
        {
            path:'/',
            meta: {title:'login'},
            component: ()=>import('../views/login.vue')
        },
        {
            path:'/login',
            redirect: '/'
        },
        {
            path:'/index',
            meta: {title:'大平台'},
            component: ()=>import('../views/index.vue'),
            children:[
                {
                    path: '',
                    meta: {title: 'index'},
                    component: ()=>import('../views/home.vue') 
                },
                {
                    path: '/mail',
                    meta: {title: 'mail'},
                    component: ()=>import('../views/mail.vue') 
                },
                {
                    path: '/message',
                    meta: {title: 'message'},
                    component: ()=>import('../views/message.vue') 
                },
                {
                    path: '/mine',
                    meta: {title: 'mine'},
                    component: ()=>import('../views/user/mine.vue') 
                },
                {
                    path: '/setpwd',
                    meta: {title: 'setpwd'},
                    component: ()=>import('../views/user/setPwd.vue') 
                },
                {
                    path: '/role',
                    meta: {title: 'role'},
                    component: ()=>import('../views/user/role.vue') 
                },
                {
                    path: '/user',
                    meta: {title: '用戶管理'},
                    component: ()=>import('../views/user/User.vue') 
                },
                {
                    path: '/roomtype',
                    meta: {title: 'roomtype'},
                    component: ()=>import('../views/room/roomType.vue') 
                },
                {
                    path: '/room',
                    meta: {title: 'room'},
                    component: ()=>import('../views/room/room.vue') 
                },
                {
                    path: '/livein',
                    meta: {title: 'livein'},
                    component: ()=>import('../views/customer/liveIn.vue') 
                },
                {
                    path: '/order',
                    meta: {title: 'order'},
                    component: ()=>import('../views/customer/order.vue') 
                },
                {
                    path: '/menu',
                    meta: {title: 'menu'},
                    component: ()=>import('../views/system/menu.vue') 
                },
                {
                    path: '/dictionary',
                    meta: {title: 'dictionary'},
                    component: ()=>import('../views/system/dictionary.vue') 
                }
            ]
        }
    ]
})

router.beforeEach((to, from, next)=>{
    next()
})

router.afterEach((to, from) => {
    if(to.meta && to.meta.title) {
        document.title = to.meta.title+''
    }
})

export default router