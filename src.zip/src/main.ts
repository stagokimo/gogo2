import { createApp } from 'vue'
import './style.css'
import App from './App.vue'

//route
import route from './router'

//
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'

//
import { createPinia } from 'pinia'

createApp(App).
use(createPinia()).
use(route).
use(ElementPlus).
mount('#app')
