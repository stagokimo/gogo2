<template>
  <el-drawer
        :before-close="handleClose"
         v-model="drawer" 
         title="I am the title" 
         :with-header="false">
         <el-form
                size="small"
                ref="formRef"
                :model="formData"
                status-icon
                :rules="rules"
                label-width="40px">

                <el-form-item label="roleId" prop="roleId">
                    <el-input v-model="formData.roleId" />
                </el-form-item>
                <el-form-item label="roleName" prop="roleName">
                    <el-input v-model="formData.roleName" />
                </el-form-item>
               
                <el-form-item>
                    <el-button type="primary" @click="submitForm(formRef)">
                        ADD
                    </el-button>
                    <el-button @click="resetForm(formRef)">CANCEL</el-button>
                </el-form-item>
            </el-form>
        </el-drawer>
</template>

<script setup lang="ts">

import {ref, reactive} from 'vue'
//element-plus 
import type { FormInstance, FormRules } from 'element-plus'

//綁定表單
const formRef = ref<FormInstance>()

const formData = reactive({
    roleId:'',
    roleName: ''
})

let drawer = ref(false)

const handleClose = () => {
    drawer.value = false
    formRef.value?.resetFields()
}

const validateRoleId = (rule: any, value: any, callback: any) => {
  if (value === '') {
    callback(new Error('Please input the password'))
  } else {
    callback()
  }
}

const validateRoleName = (rule: any, value: any, callback: any) => {
  if (value === '') {
    callback(new Error('Please input the account'))
  } else {
    callback()
  } 
}

const rules = reactive<FormRules<typeof formData>>({
    roleId: [{ validator: validateRoleId, trigger: 'blur' }],
    roleName: [{ validator: validateRoleName, trigger: 'blur' }],
})

const submitForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.validate(async (valid) => {
    if (valid) {

      //
      formEl.resetFields()

    } else {
      console.log('error submit!')
      formEl.resetFields()
    }
  })
}

const resetForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.resetFields()
}

defineExpose({
    drawer
})

</script>

<style scoped lang="scss">

</style>