<template>
  <ul class="menu bg-slate-300 w-56 h-dvh mb-8 rounded-box">
    <div class="card w-auto bg-base-100 shadow-xl">
      <div class="card-body">
        <h2 class="card-title">Card title!</h2>
        <p>If a dog chews shoes whose shoes does he choose?</p>
        <div class="card-actions justify-end">
          <button class="btn btn-primary">Buy Now</button>
        </div>
      </div>
    </div>

    <li><a><router-link to="/home">Go to Home</router-link></a></li>
    <li><a><router-link to="/sample">Go to Sample</router-link></a></li>
    <li>
      <details open>
        <summary>Parent</summary>
        <ul>
          <li><a>Submenu 1</a></li>
          <li><a>Submenu 2</a></li>
          <li>
            <details open>
              <summary>Parent</summary>
              <ul>
                <li><a>Submenu 1</a></li>
                <li><a>Submenu 2</a></li>
              </ul>
            </details>
          </li>
        </ul>
      </details>
    </li>
    <li><a><router-link to="/about">Go to About</router-link></a></li>
  </ul>
</template>
