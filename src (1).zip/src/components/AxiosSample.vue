<script setup lang="ts">
import { ref } from 'vue';
import axios from 'axios';

// 定義一個 ref 來存儲待辦事項
const todo = ref(null);

// 定義一個函數來獲取待辦事項
const fetchTodo = async () => {
    try {
        const response = await axios.get('https://jsonplaceholder.typicode.com/todos/1');
        todo.value = response.data;
    } catch (error) {
        console.error('Error fetching todo:', error);
    }
};

// 在組件加載時自動加載數據
fetchTodo();

</script>

<template>
    <div>
        <h1>Todo Item</h1>
        <div v-if="todo">
            <p><strong>ID:</strong> {{ todo.id }}</p>
            <p><strong>Title:</strong> {{ todo.title }}</p>
            <p><strong>Completed:</strong> {{ todo.completed }}</p>
        </div>
        <div v-else>
            <p>Loading...</p>
        </div>
        <button @click="fetchTodo">Fetch Todo</button>
    </div>
</template>