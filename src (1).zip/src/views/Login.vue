<template>
  <div>
    <form @submit.prevent="onLogin">
      <label for="user">user : </label>
      <input type="text" v-model="userName" />
      <br />
      <label for="passwrd">passwrd : </label>
      <input type="text" v-model="userPassword" />
      <br />
      <button class="btn btn-primary">登入</button>

      <label v-if="$route.params.status==='fail'" style="color: red;">登入失敗</label>
    </form>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import router from '../router/router'

const userName = ref('')
const userPassword = ref('')

const onLogin = async () => {
  console.log('userName : ', userName.value)
  console.log('userPassword : ', userPassword.value)

  

  if (userName.value != '' && userPassword.value != '') {
    setCookie("username", userName.value, 30);

    router.push({ name: 'home' })
  } else {
    alert('帳號密碼不能為空')
  }
}

const setCookie = (cname: string, cvalue: any, exdays: any)=> {
    const d = new Date()
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000)
    let expires = 'expires=' + d.toUTCString()
    document.cookie = "username" + '=' + cvalue + ';' + expires + ';path=/'
}
</script>
