<template>
  <div class="about">
    <div role="tablist" class="tabs tabs-lifted">
      <a role="tab" class="tab">Tab 1</a>
      <a role="tab" class="tab">Tab 2</a>
      <a role="tab" class="tab">Tab 3</a>
    </div>
  </div>
</template>

<style></style>
