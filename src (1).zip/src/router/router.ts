import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginView from '../views/Login.vue'
import AuthLayout from '@/views/layout/AuthLayout.vue'
import MainLayout from '@/views/layout/MainLayout.vue'
import Sample from '@/components/DaisyuiSample.vue'
import About from '@/views/AboutView.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [ 
    {
      path: '/',
      redirect: 'login',
      name: 'LoginView',
      component: AuthLayout,
      children: [
        {
          path: 'login',
          name: 'login',
          component: LoginView
        },
        {
          path: 'login/:status',
          name: 'relogin',
          component: LoginView
        }
    
      ]
    },
    {
      path: '/',
      redirect: 'home',
      component: MainLayout,
      meta: { requireAuth: true }, // 用來作為此頁是否需要權限驗證的設定
      children: [
        {
          path: '/home',
          name: 'home',
          component: HomeView
        },
        {
          path: '/sample',
          name: 'sample',
          component: Sample
        },
        {
          path: '/about',
          name: 'about',
          component: About
        },
      ]
    },
   
  ]
})


router.beforeEach(async(to, from) => {
  // 看看 to 和 from 兩個 arguments 會吐回什麼訊息
  console.log('to: ', to)
  console.log('from: ', from)
  // 目的路由在meta上是否有設置requireAuth: true
  if (to.meta.requireAuth) {
    let user = getCookie("username");

    if(to.name !== 'login' && user != 'zack') {
      console.log('asdasd')
      return { name: 'relogin', params: {status: 'fail'} }
    }

  }
})

const getCookie = (cname: string)=>{
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

export default router
